<html>
<head>
<title>homepage
</title>	  
</head>
<style>
body{
 background-color: #3a9dca;
}
 </style>
<div style="margin-full: 100px; background: #3a9dca;">
<body>
<br/>

		<div class="container">
			<div class="row">
				<div style="margin-top: 30px; background: #3a9dca;">
					<div class="contact-heading text-center">
						<center><h1 style="color:black;"style="font-size:400%;"><B>NASA MANAGEMENT SYSTEM</B></h1></center>
						<center><img src="img/logo.png" style="width:250px;height:250px;">
					</div><br/>
					<center><table style="border-width:2px;"></center>
				
				<ul>
  <size="100"><a href="AdminLogin.php">ADMIN LOGIN</a><br><br>
  <a href="ScientistLogin.php">SCIENTIST LOGIN</a></li><br><br>
  <a href="VisitorLogin.php">VISITOR LOGIN</a></li><br><br>
  <a href="Visitors.php">NEW VISITOR</a></li><br><br>
</ul>
</div>
			</div>
		</div>

		

</body>
</html>



