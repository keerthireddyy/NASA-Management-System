<!DOCTYPE html>
<html lang="en"> 
<head>
		
<?php
//Turn off
error_reporting(0);
  include "Head.php";
  ?>
</head>
<body>
<?php
//Turn off
error_reporting(0);
  include "SHeader.php";
  ?>
<br/>
	<?php echo @$err;?> 
	
	<?php
//Turn off
error_reporting(0);
  include "Footer.php";
  ?>
</body>
</html>